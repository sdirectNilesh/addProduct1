const { Sequelize } = require("sequelize")
const {DataTypes} = require("sequelize")
const sequelize = require("../Database/db")
const userModel = require("./userModel")
const Nilproduct_obj = require("./prodModel")

const Nilproductcart_obj = sequelize.define('Nilproductcart_obj', {
    // Model attributes are defined here
    userId: {
        type: DataTypes.STRING,
    },
    productId: {
        type: DataTypes.INTEGER,
    },
    count: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
})
userModel.hasMany(Nilproductcart_obj, {
    foreignKey: "userId"
})
Nilproductcart_obj.belongsTo(userModel, {
    foreignKey: "userId"
})


Nilproduct_obj.hasMany(Nilproductcart_obj, {
    foreignKey: "productId"
})
Nilproductcart_obj.belongsTo(Nilproduct_obj, {
    foreignKey: "productId"
})

module.exports = Nilproductcart_obj;