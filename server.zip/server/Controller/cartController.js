const Nilproductcart_obj = require('../Models/cartModel');
const userModel = require("../Models/userModel")
const Nilproduct_obj = require("../Models/prodModel")
const { Op } = require("sequelize");

exports.addtoCart = async (req, res) => {
    try {
        console.log(req.body);
        
        const cart = {
            productId: req.body.productId,
            userId: req.body.userId,
            count: req.body.count,
        };
        let user = await userModel.findByPk(cart.userId);
        let product = await Nilproduct_obj.findByPk(cart.productId);
        if(user&&product){
            let created_cart = await Nilproductcart_obj.create(cart);
            return res.status(201).json({ product: created_cart });
        }
        else{
            return res.status(400).json({ error: 'Missing required fields.' });
        }

    } catch (error) {
        console.log(error)
    }
}

exports.getCart = async(req, res) => {
  try {
    const userId = req.params.id
    const data = await Nilproductcart_obj.findAll({ 
        where: { userId: userId },
        include:[
            {model:Nilproduct_obj},
        ]
    });
    res.status(201).json({ product: data });
  } catch (error) {
    console.log("error at get cart: ", error)
  }
}