import React from 'react'

function Pagenotfound() {
    return (
        <div>
            <div class="card text-center">
                <div class="card-header" style={{background: "#B70404"}}>
                    <span>Page Not Found</span>
                </div>
            </div>
        </div>
    )
}

export default Pagenotfound