import React, { useEffect, useState } from 'react'
import { Col, Button, Row, Form, Card, Container } from "react-bootstrap"
import axios from 'axios'
import Table from 'react-bootstrap/Table';
import Dropdown from 'react-bootstrap/Dropdown';
import jwt_decode from "jwt-decode";
import { Link, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';




function Product() {


    const decode = jwt_decode(localStorage.getItem('token'));
    const [userId, setUserId] = useState(decode.userId);
    const [products, setProducts] = useState([]);
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [productId, setProductId] = useState(null);
    const [count, setCount] = useState(1);
    const navigate = useNavigate();


    const fetchAllProducts = async () => {

        const { data } = await axios.get(
            ' http://localhost:5001/get-allproduct'
        );
        const products = data.product;
        setProducts(products);
        console.log("data: ", data);
    };

    useEffect(() => {
        fetchAllProducts();
    }, []);

    const userLogout = () => {

        const token = localStorage.clear();
        console.log("tok: ", token);
        if (!token) {
            navigate("/");
        }
    }

    const addtoCart = (productId) => {
        console.log("productId: ",productId);

        const response = axios
            .post('http://localhost:5001/add-cart',
                {   productId,
                    userId,
                    count,
                }
            ).then((response) => {
                console.log(response);
                navigate("/product/cart");
            }).catch(() => {
                console.log("err");
            });
    }


    return (
        <div>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <a class="navbar-brand" href="#">Products</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <Link to="/product/home">Home</Link>
                    </div>
                </div>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup" style={{ marginRight: "850px" }}>
                    <div class="navbar-nav">
                        <Link to="/product/home/updatepassword">UpdatePasword</Link>
                    </div>
                </div>
                <Button className='btn' style={{ marginRight: "1.6%", width: "8%" }} onClick={userLogout}>Logout</Button>
            </nav>
            <br></br>
            <Table class="table" >
                <thead>
                    <tr>
                        <th scope="col">Index</th>
                        <th scope="col">BRAND</th>
                        <th scope='col'>Price</th>
                        <th scope='col'>Category</th>
                    </tr>
                </thead>
                <tbody >
                    {products?.length > 0 && products.map((product) => (

                        <tr>
                            <th scope="row">{product.productId}</th>
                            <td>{product.product1}</td>
                            <td>{product.productPrice}</td>
                            <td>{product.category}</td>

                            <td>
                                <Form.Group as={Col} controlId="formGridState">
                                    <Form.Select defaultValue="1" placeholder="Count" onChange={(e) => setCount(e.target.value)} required>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                    </Form.Select>
                                </Form.Group>
                            </td>
                            <td><Button onClick={() => { addtoCart(product.productId) }} >Add To Cart</Button></td>
                        </tr>

                    ))
                    }
                </tbody>
            </Table>
        </div >
    )
}

export default Product;